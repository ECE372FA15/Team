
// File:         switch.h
// Date:         9/24/2015
// Authors:      Brandon Lipjanic
//               Jonathan Hawkins
//               Abigail Francis
//               Pierce Simpson

#ifndef SWITCH_H
#define	SWITCH_H

void initSW();


#endif	/* SWITCH_H */

